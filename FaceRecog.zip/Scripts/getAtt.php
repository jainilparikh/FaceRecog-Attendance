<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendance";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
	$usn=$_POST['usn'];

	$sql_select = "SELECT Days from IMAD WHERE USN = \"".$usn."\";";

	$result = $conn->query($sql_select);
	
	if($result->num_rows>0)
	{
		$row=mysqli_fetch_row($result);
		echo $row[0];
	}

	$conn->close();

}

?>