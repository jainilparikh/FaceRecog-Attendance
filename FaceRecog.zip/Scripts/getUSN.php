<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendance";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
} 

$sql_select = "SELECT USN FROM IMAD WHERE USN NOT IN (SELECT USN FROM STUDENTS);";
$result = $conn->query($sql_select);


for ($i=0;$i<$result->num_rows;$i++) 
{
	$row=mysqli_fetch_row($result);
	echo $row[0];

	if($i!=$result->num_rows-1)
		echo ",";
} 

$conn->close();
	
 
?>