<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendance";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
	$uname = $_POST['username'];
	$pwd = $_POST['password'];
	$usn=$_POST['usn'];
	$param_password = password_hash($pwd, PASSWORD_DEFAULT);

	$sql="INSERT INTO STUDENTS VALUES (\"".$usn."\",\"".$uname."\",\"".$param_password."\")";
	if($conn->query($sql))
		echo "Registered";
	else
		echo "Try again";
}
	
$conn->close();
	
 
?>