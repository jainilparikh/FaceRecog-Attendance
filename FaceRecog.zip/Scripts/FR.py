import socket
import json
import os
import asyncio
import io
import glob
import sys
import time
import uuid
import requests
from urllib.parse import urlparse
from io import BytesIO
from PIL import Image, ImageDraw
import cv2
from azure.cognitiveservices.vision.face import FaceClient
from msrest.authentication import CognitiveServicesCredentials
from azure.cognitiveservices.vision.face.models import TrainingStatusType, Person, SnapshotObjectType, OperationStatusType

from _thread import *
import threading
import face_recognition


KEY = 'API-KEY'

ENDPOINT = 'https://facerecog-android.cognitiveservices.azure.com/'

face_client = FaceClient(ENDPOINT, CognitiveServicesCredentials(KEY))

PERSON_GROUP_ID = 'my-unique-person-group'

TARGET_PERSON_GROUP_ID = str(uuid.uuid4()) 

thread_lock = threading.Lock() 

def listToString(s):  
    
    str1 = ""  
     
    for ele in s:  
        str1 += ","+ele   
      
    return str1[1:]  


def threaded(c,addr): 

 face_strings=""

 try:
  print("Connected to PHP")
  _req = c.recv(1024)

  if not _req: 
   print('No data') 

  my_json2 = _req.decode('utf8').replace("'", '"')
        
  req = json.loads(my_json2)

  if(req["flags"]=="FILEUPLOAD"):
   file_name=req["file_name"] #file name 
   print(file_name)
   file_name=""+file_name #Add the path of the image to the string

   if(not file_name.endswith('.jpg') and not file_name.endswith('.png')):
    c.send("Video not supported currently".encode('utf-8'))
    exit_thread()    

  image= open(file_name, 'r+b')
  #Detect faces
  face_ids = []
  faces = face_client.face.detect_with_stream(image)

  print(dir(faces))
  for face in faces:
   face_ids.append(face.face_id)
  
  results = face_client.face.identify(face_ids, PERSON_GROUP_ID)
  

  print('Identifying faces in {}'.format(os.path.basename(image.name)))
  print(results)
  if not results:
   print('No person identified in the person group for faces from {}.'.format(os.path.basename(image.name)))
  
  face_list=[]
  for person in results:
   if(len(person.candidates) != 0):
    candidate_id=person.candidates[0].person_id;
    print("C: ",candidate_id)   
    person_check=face_client.person_group_person.get(PERSON_GROUP_ID,candidate_id)
    print(person_check.name)
    face_strings = face_strings + ","+ person_check.name
    face_list.append(person_check.name)
    print('Person for face ID {} is identified in {} with a confidence of {}.'.format(person.face_id, os.path.basename(image.name), person.candidates[0].confidence)) 


  face_strings=face_strings[1:]

  face_list=list(set(face_list))

  print("Face List: ",face_list)
  print(listToString(face_list))
        
  print(face_strings)

 except:
  print("Exception") 
  
 if(len(face_strings)==0):
  c.send("No faces detected".encode('utf-8'))
 else:
  c.send(listToString(face_list).encode('utf-8')) #String which contains all the names
 
 exit_thread()

def Train():
    
    print('Person group:', PERSON_GROUP_ID)


    p={}
    usns=["1RV17CS042","1RV17CS108","1RV17CS074","1RV17CS017","1RV17CS063","1RV17CS022","1RV17CS041","1RV17CS026","1RV17CS003"] #USNS trained
    
    for i in range (0,len(usns)):
        p[usns[i]]=face_client.person_group_person.create(PERSON_GROUP_ID, usns[i])
  
    images={}
   
    for i in range(0,len(usns)):
        images[usns[i]] = [file for file in glob.glob('*.jpg') if file.startswith(usns[i])]
    
    
    for i in range(0,len(usns)):
        for image in images[usns[i]]:
            w = open(image, 'r+b')
            print(image)
            print(p[usns[i]].person_id)
            face_client.person_group_person.add_face_from_stream(PERSON_GROUP_ID, p[usns[i]].person_id, w)

    
    print()
    print('Training the person group...')
    
    face_client.person_group.train(PERSON_GROUP_ID)

    while (True):
        training_status = face_client.person_group.get_training_status(PERSON_GROUP_ID)
        print("Training status: {}.".format(training_status.status))
        print()
        if (training_status.status is TrainingStatusType.succeeded):
            break
        elif (training_status.status is TrainingStatusType.failed):
            sys.exit('Training the person group has failed.')
        time.sleep(5)

def Main():
    #Train() Uncommnet this to train new people
    host = ""
    
    port = 12345
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print("Socket successfully created")
     
    s.bind((host, port)) 

    print("Socket binded to port", port) 
  
    s.listen(5) 
    print("socket is listening") 
  
    while True: 
  
        c, addr = s.accept() 

        start_new_thread(threaded, (c,addr,)) 

    s.close() 
  
  
if __name__ == '__main__': 
    Main() 

