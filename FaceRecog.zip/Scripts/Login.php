<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendance";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
	$usn=$_POST['usn'];
	$pwd = $_POST['password'];
	$param_password = password_hash($pwd, PASSWORD_DEFAULT);

	$sql="SELECT Password FROM STUDENTS WHERE USN = \"".$usn."\";";
	$results=$conn->query($sql);

	if($results->num_rows>0)
	{
		$row=mysqli_fetch_row($results);

		if(password_verify($pwd,$row[0]))
			echo "Valid";
		else 
			echo "Invalid USN or Password";	
	}
	else
	{
		echo "Invalid USN or Password";
	}

}
?>