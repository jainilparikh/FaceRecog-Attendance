<?php
 
// Path to move uploaded files
$target_path = "uploads\\";
 
// array for final json respone
$response = array();
 
// getting server ip address
$server_ip = gethostbyname(gethostname());
 
// final file url that is being uploaded
$file_upload_url = 'http://' . $server_ip . '/' . 'AndroidFileUpload' . '/' . $target_path;

 
if (isset($_FILES['image']['name']))
{
    $target_path = $target_path . basename($_FILES['image']['name']);
 
    // reading other post parameters
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $website = isset($_POST['website']) ? $_POST['website'] : '';
 
    $response['file_name'] = basename($_FILES['image']['name']);
    $response['email'] = $email;
    $response['website'] = $website;
 
    try
	{
		// Throws exception incase file is not being moved
		if (!move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
			// make error flag true
			$response['error'] = true;
			$response['message'] = 'Could not move the file!';
    }

	$name =basename($_FILES['image']['name']);

	$host    = "127.0.0.1";
	$port    = 12345;
	$message = "{
		'flags': 'FILEUPLOAD',
		'file_name': '$name'
	}";

	//echo "Message To server :".$message;
	// create socket
	$socket = socket_create(AF_INET, SOCK_STREAM, 0) or die("Could not create socket\n");
	// connect to server
	$result = socket_connect($socket, $host, $port) or die("Could not connect to server\n");  
	// send string to server
	socket_write($socket, $message, strlen($message)) or die("Could not send data to server\n");
	// get server response
	$result = socket_read ($socket, 1024) or die("Could not read server response\n");
	//echo "Reply From Server  :".$result;
	// close socket
	socket_close($socket);

	//print_r($result);

	$usns=array();
 
    // File successfully uploaded

	if(strcmp($result,"Video not supported currently")!=0)
	{
		if(strcmp($result,"No faces detected")!=0)
		{

			$usns=explode(",",$result);
			$response="USNs of the people in the photo: ".implode(", ",$usns);
		
	
		}
		else
		{
			$response="No known faces detected";
		}
	}
	else
	{
		$response=$result;
	
	}

    
	} 
	catch (Exception $e) 
	{
        // Exception occurred. Make error flag true
        $response['error'] = true;
        $response['message'] = $e->getMessage();
    }

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "attendance";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	} 

	$update = $conn->prepare("UPDATE IMAD SET Days=Days+1 WHERE USN= ?");

	if($update)
	{
		$update->bind_param("s",$usn);
		for($i=0;$i<count($usns);$i++)
		{
			$usn=$usns[$i];
			$update->execute();	
	
		}
	}



} else {
    // File parameter is missing
    $response['error'] = true;
    $response['message'] = 'Not received any file!F';
}
 
// Echo final json response to client
echo $response;
?>