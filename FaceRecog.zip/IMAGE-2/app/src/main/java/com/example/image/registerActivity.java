package com.example.image;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Arrays;

public class registerActivity extends Activity {
    String uname,pass,usn;
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.register_page);
        final EditText username = (EditText) findViewById(R.id.username);
        //final EditText username = (EditText) findViewById(R.id.username);
        final EditText password = (EditText) findViewById(R.id.password);
        //final EditText subject = (EditText) findViewById(R.id.subject);

        Spinner s=(Spinner)findViewById(R.id.usns_spinner);

        s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                usn= parent.getItemAtPosition(pos).toString();
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        Button submit = (Button) findViewById(R.id.submit);



        new getUSN().execute();
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {

                    uname=username.getText().toString();
                    pass=password.getText().toString();

                    if(uname.isEmpty()||pass.isEmpty())
                        throw new NullPointerException();
                    new register().execute();
                    Toast.makeText(getApplicationContext(), "Registration successful", Toast.LENGTH_LONG);
                    finish();

                } catch (NullPointerException e) {


                    Toast.makeText(getApplicationContext(), "Username or Password not filled", Toast.LENGTH_LONG).show();


                }
                catch(Exception e)
                {

                    Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();

                }

            }
        });
    }

    private class getUSN extends AsyncTask<Void, Integer, String> {
        @Override
        protected void onPreExecute() {

        }


        @Override
        protected String doInBackground(Void... params) {
            try {

                URL url = new URL(Config.USN_URL);
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(Config.USN_URL));

                HttpResponse response = client.execute(request);
                BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

                //BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder sb = new StringBuilder();
                String line = null;

                // Read Server Response
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }

                System.out.println("SBCheck: " + sb.toString());

                return sb.toString();

            } catch (Exception e) {
                System.out.println("Exception: SA " + e.getMessage());
                e.printStackTrace();

                return e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result)
        {
            populateSpinner(result);
            super.onPostExecute(result);
        }
    }
    private class register extends AsyncTask<Void, Integer, String> {
        @Override
        protected void onPreExecute() {

        }


        @Override
        protected String doInBackground(Void... params) {
            try {

                String data  = URLEncoder.encode("username", "UTF-8") + "=" +
                        URLEncoder.encode(uname, "UTF-8");
                data += "&" + URLEncoder.encode("password", "UTF-8") + "=" +
                        URLEncoder.encode(pass, "UTF-8");
                data+= "&" + URLEncoder.encode("usn", "UTF-8") + "=" +
                        URLEncoder.encode(usn, "UTF-8");
                data+= "&" + URLEncoder.encode("submit", "UTF-8") + "=" +
                        URLEncoder.encode("", "UTF-8");

                URL url = new URL(Config.Register_URL);
                URLConnection conn = url.openConnection();

                conn.setDoOutput(true);
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                wr.write( data );
                wr.flush();

                BufferedReader in = new BufferedReader(new
                        InputStreamReader(conn.getInputStream()));

                StringBuilder sb = new StringBuilder();
                String line = null;


                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }

                in.close();

                System.out.println("SBCheck: " + sb.toString());

                return sb.toString();

            } catch (Exception e) {
                System.out.println("Exception: SA " + e.getMessage());
                e.printStackTrace();

                return e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result)
        {
            if(result.equals("Registered")) {
                Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_LONG).show();
                finish();
            }
            else
            {
                Toast.makeText(getApplicationContext(), "Registration Unsuccessful. Try Again", Toast.LENGTH_LONG).show();

            }

        }
    }



    public void populateSpinner(String result)
    {
        String[] USN= result.split(",",0);

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, Arrays.asList(USN));

        // Drop down layout style - list view with radio button
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Spinner USNS_Spinner=(Spinner)findViewById(R.id.usns_spinner);
        USNS_Spinner.setAdapter(spinnerAdapter);
    }

}