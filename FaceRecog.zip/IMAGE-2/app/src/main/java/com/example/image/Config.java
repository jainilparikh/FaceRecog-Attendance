package com.example.image;

public class Config
{
        // File upload url (replace the ip with your server address)
        static String IP="223.226.97.195";
        public static final String FILE_UPLOAD_URL = "http://"+IP+":8080/AndroidFileUpload/fileUpload.php";
        public static final String ATT_URL="http://"+IP+":8080/AndroidFileUpload/getAtt.php";
        public static final String USN_URL="http://"+IP+":8080/AndroidFileUpload/getUSN.php";
        public static final String Register_URL="http://"+IP+":8080/AndroidFileUpload/Register.php";
        public static final String Login_URL="http://"+IP+":8080/AndroidFileUpload/Login.php";


        public static final String IMAGE_DIRECTORY_NAME="Android File Upload";

}
