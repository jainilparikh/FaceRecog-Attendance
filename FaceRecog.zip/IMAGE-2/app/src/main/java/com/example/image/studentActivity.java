package com.example.image;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

public class studentActivity extends AppCompatActivity {
    String usn;

    TextView usnText,Att;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.student_page);
        Intent intent = getIntent();
        usn = intent.getStringExtra("USN");

        usnText=(TextView)findViewById(R.id.USNText);
        Att=(TextView)findViewById(R.id.Att);

        usnText.setText("USN: "+usn);

        System.out.println("USN Logged in: "+usn);

        new getAtt().execute();
    }

    private class getAtt extends AsyncTask<Void, Integer, String> {
        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(Void... params) {
            try {

                String data  = URLEncoder.encode("usn", "UTF-8") + "=" +
                        URLEncoder.encode(usn, "UTF-8");
                data+= "&" + URLEncoder.encode("submit", "UTF-8") + "=" +
                        URLEncoder.encode("", "UTF-8");

                URL url = new URL(Config.ATT_URL);
                URLConnection conn = url.openConnection();

                conn.setDoOutput(true);
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                wr.write( data );
                wr.flush();

                BufferedReader in = new BufferedReader(new
                        InputStreamReader(conn.getInputStream()));

                StringBuilder sb = new StringBuilder();
                String line = null;


                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }

                in.close();

                System.out.println("SBCheck: " + sb.toString());

                return sb.toString();


            } catch (Exception e) {
                System.out.println("Exception: SA " + e.getMessage());
                e.printStackTrace();

                return e.getMessage();
            }

        }


        @Override
        protected void onPostExecute(String result) {
            Log.e("test123", "Response from server: " + result);

            Att.setText("IMAD\n\nNo. of days attended: "+result);

            super.onPostExecute(result);
        }


    }


}

