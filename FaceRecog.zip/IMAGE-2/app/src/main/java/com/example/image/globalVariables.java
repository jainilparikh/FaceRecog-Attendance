package com.example.image;

public class globalVariables {
   public static String username= "";
   public static String name_list="";
}
