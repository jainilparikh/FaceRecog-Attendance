package com.example.image;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import com.example.image.globalVariables;

import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class loginActivity extends Activity  {
    String usn,pass;


public void onCreate(Bundle savedInstanceStatendle){
    super.onCreate(savedInstanceStatendle);

    setContentView(R.layout.login_page);

    final EditText usnText = (EditText) findViewById(R.id.usnEditText);
    final EditText password  = (EditText) findViewById(R.id.passwordEditText);
    Button login = (Button)findViewById(R.id.loginButton);
    final Switch switch_value = (Switch)findViewById(R.id.switch2);
    final Button register = (Button)findViewById(R.id.registerButton);

    switch_value.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if(isChecked)
            {
                usnText.setHint("Username");
                switch_value.setText("Swipe for Student login!");
            }
            else
            {
                usnText.setHint("USN");
                switch_value.setText("Swipe for Teacher login!");
            }
        }
    });
    login.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                int counter = 0;
                Log.d("This is a", Boolean.toString(switch_value.isChecked()));

                usn=usnText.getText().toString();
                pass=password.getText().toString();



                if (switch_value.isChecked())
                {
                    if (usnText.getText().toString().equals("admin")) {
                        if (password.getText().toString().equals("admin")) {
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Please check username or password", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Please check username or password", Toast.LENGTH_LONG).show();
                    }
                }
                else
                    new login().execute();

            }
            catch (Exception e)
            {
                Log.d("This is an exception",e.toString());
                Toast.makeText(getApplicationContext(),"Please Register!",Toast.LENGTH_LONG).show();
            }
        }
    });
    register.setOnClickListener(new View.OnClickListener()
    {
        public void onClick(View v)
        {
            Intent intent = new Intent(getApplicationContext(),registerActivity.class);
            startActivity(intent);
        }
    });

    }
    private class login extends AsyncTask<Void, Integer, String> {
        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(Void... params) {
            try {

                String data  = URLEncoder.encode("usn", "UTF-8") + "=" +
                        URLEncoder.encode(usn, "UTF-8");
                data += "&" + URLEncoder.encode("password", "UTF-8") + "=" +
                        URLEncoder.encode(pass, "UTF-8");
                data+= "&" + URLEncoder.encode("submit", "UTF-8") + "=" +
                        URLEncoder.encode("", "UTF-8");

                URL url = new URL(Config.Login_URL);
                URLConnection conn = url.openConnection();

                conn.setDoOutput(true);
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                wr.write( data );
                wr.flush();

                BufferedReader in = new BufferedReader(new
                        InputStreamReader(conn.getInputStream()));

                StringBuilder sb = new StringBuilder();
                String line = null;


                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }

                in.close();

                System.out.println("SB Check: " + sb.toString());

                return sb.toString();

            } catch (Exception e) {
                System.out.println("Exception: SA " + e.getMessage());
                e.printStackTrace();

                return e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result)
        {
            if(result.equals("Valid")) {
                Intent intent = new Intent(getApplicationContext(), studentActivity.class);
                intent.putExtra("USN",usn);
                startActivity(intent);
            }
            else
            {
                Toast.makeText(getApplicationContext(), "Invalid USN or Password", Toast.LENGTH_LONG).show();

            }

        }
    }
}